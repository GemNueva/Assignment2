﻿const Home = ({ }) => {
    return (

        <div>
            <h2 className="text-center">
                Route: Home
            </h2>
            <hr />

            <p>
                Body: baodsjnqon jdnsadojn jnaso

            </p>


        </div>

    );
}


export default Home;
